<?php
require 'tts_config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if ($password !== $confirm_password) {
        $error = "Passwords do not match!";
    } else {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Start Transaction
        $conn->begin_transaction();

        try {
            // Insert User
            $stmt = $conn->prepare("INSERT INTO users (username, first_name, last_name, email, password) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("sssss", $username, $first_name, $last_name, $email, $hashed_password);
            $stmt->execute();
            $new_user_id = $conn->insert_id;

            // Create Empty Profile
            $stmt = $conn->prepare("INSERT INTO profiles (user_id, image) VALUES (?, 'default_avatar.png')");
            $stmt->bind_param("i", $new_user_id);
            $stmt->execute();

            $conn->commit();
            echo "<script>alert('Account created! Please log in.'); window.location.href='login.php';</script>";
            exit();

        } catch (Exception $e) {
            $conn->rollback();
            $error = "Error: Username or Email already exists.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sign Up | Recipe Share</title>
    <link rel="stylesheet" href="signup.css">
    <link rel="stylesheet" href="login.css">
    <style>
        /* Hide the browser's default password reveal button to prevent overlapping */
        input[type="password"]::-ms-reveal,
        input[type="password"]::-ms-clear {
            display: none;
        }
        
        /* Orange Button Styling */
        .btn {
            background-color: #ff7e54 !important;
            color: white !important;
            border: none;
            cursor: pointer;
            transition: background 0.3s;
        }
        .btn:hover {
            background-color: #e66d46 !important;
        }

        /* Password Reveal Styles */
        .password-wrapper {
            position: relative;
            width: 100%;
        }
        .password-wrapper input {
            width: 100%;
            padding-right: 40px; /* Space for the eye icon */
            box-sizing: border-box;
        }
        .toggle-password {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            cursor: pointer;
            color: #777;
            padding: 0;
            display: flex;
            align-items: center;
            outline: none;
        }
        .toggle-password:hover { color: #333; }
        .toggle-password svg { width: 20px; height: 20px; }

        /* Ensure form container is centered and clean */
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-color: #f4f4f4; /* Light gray background */
            margin: 0;
            font-family: sans-serif;
        }
        .form-container {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 400px;
        }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: bold; }
        .form-group input { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; }
    </style>
</head>
<body>

    <div class="form-container">
        <h2 style="text-align:center; color:#333;">Create Your Account</h2>
        
        <?php if(isset($error)) echo "<p style='color:red; text-align:center;'>$error</p>"; ?>
        
        <form action="signup.php" method="POST">
            <div class="form-group"><label>Username</label><input type="text" name="username" required></div>
            <div class="form-group"><label>First Name</label><input type="text" name="first_name" required></div>
            <div class="form-group"><label>Last Name</label><input type="text" name="last_name" required></div>
            <div class="form-group"><label>Email</label><input type="email" name="email" required></div>
            
            <div class="form-group">
                <label>Password</label>
                <div class="password-wrapper">
                    <input type="password" name="password" id="pass1" required>
                    <button type="button" class="toggle-password" onclick="togglePassword('pass1')">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
                    </button>
                </div>
            </div>
            
            <div class="form-group">
                <label>Confirm Password</label>
                <div class="password-wrapper">
                    <input type="password" name="confirm_password" id="pass2" required>
                    <button type="button" class="toggle-password" onclick="togglePassword('pass2')">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
                    </button>
                </div>
            </div>

            <button type="submit" class="btn" style="width:100%; padding: 12px; font-weight: bold; border-radius: 5px;">Sign Up</button>
        </form>
        
        <p style="text-align:center; margin-top:15px;">Already have an account? <a href="login.php" style="color:#ff7e54; text-decoration:none;">Login</a></p>
    </div>

    <script>
        function togglePassword(inputId) {
            const input = document.getElementById(inputId);
            if (input.type === "password") {
                input.type = "text";
            } else {
                input.type = "password";
            }
        }
    </script>
</body>
</html>