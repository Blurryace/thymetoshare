<?php
session_start();
require 'tts_config.php';

// Security Check
if (!isset($_SESSION['is_staff']) || $_SESSION['is_staff'] != 1) { header("Location: home.php"); exit(); }

// Fetch Recipes with Author Name
$sql = "SELECT recipes.*, users.username FROM recipes JOIN users ON recipes.user_id = users.user_id ORDER BY date_posted DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Recipes | Admin</title>
    <link rel="stylesheet" href="style.css">
    <style>
        table { width: 100%; border-collapse: collapse; background: white; margin-top: 20px; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background-color: #333; color: white; }
    </style>
</head>
<body>
    <nav>
        <a href="admin_dashboard.php" class="nav-brand">Admin Dashboard</a>
        <a href="admin_dashboard.php" style="color:white; font-weight:bold;">Back</a>
    </nav>

    <main>
        <h2>Manage Recipes</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Author</th>
                    <th>Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['recipe_id']; ?></td>
                    <td><a href="recipedetail.php?id=<?php echo $row['recipe_id']; ?>" target="_blank"><?php echo htmlspecialchars($row['title']); ?></a></td>
                    <td><?php echo htmlspecialchars($row['username']); ?></td>
                    <td><?php echo date("M j, Y", strtotime($row['date_posted'])); ?></td>
                    <td>
                        <a href="admin_delete.php?type=recipe&id=<?php echo $row['recipe_id']; ?>" 
                           style="color:red; font-weight:bold;" 
                           onclick="return confirm('Delete this recipe?');">Delete</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </main>
</body>
</html>