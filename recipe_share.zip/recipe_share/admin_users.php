<?php
session_start();
require 'tts_config.php';

// Security Check
if (!isset($_SESSION['is_staff']) || $_SESSION['is_staff'] != 1) { header("Location: home.php"); exit(); }

// Fetch Users
$result = $conn->query("SELECT * FROM users ORDER BY user_id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Users | Admin</title>
    <link rel="stylesheet" href="style.css">
    <style>
        table { width: 100%; border-collapse: collapse; background: white; margin-top: 20px; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background-color: #333; color: white; }
        .badge-admin { background: #28a745; color: white; padding: 3px 8px; border-radius: 4px; font-size: 0.8em; }
        .badge-user { background: #6c757d; color: white; padding: 3px 8px; border-radius: 4px; font-size: 0.8em; }
    </style>
</head>
<body>
    <nav>
        <a href="admin_dashboard.php" class="nav-brand">Admin Dashboard</a>
        <a href="admin_dashboard.php" style="color:white; font-weight:bold;">Back</a>
    </nav>

    <main>
        <h2>Manage Users</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['user_id']; ?></td>
                    <td><?php echo htmlspecialchars($row['username']); ?></td>
                    <td><?php echo htmlspecialchars($row['email']); ?></td>
                    <td>
                        <?php echo ($row['is_staff'] == 1) ? '<span class="badge-admin">Admin</span>' : '<span class="badge-user">User</span>'; ?>
                    </td>
                    <td>
                        <?php if($row['user_id'] != $_SESSION['user_id']): // Prevent deleting yourself ?>
                            <a href="admin_delete.php?type=user&id=<?php echo $row['user_id']; ?>" 
                               style="color:red; font-weight:bold;" 
                               onclick="return confirm('Are you sure? This will delete the user AND their recipes.');">Delete</a>
                        <?php else: ?>
                            <span style="color:#aaa;">(You)</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </main>
</body>
</html>