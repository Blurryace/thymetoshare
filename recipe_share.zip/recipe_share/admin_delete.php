<?php
session_start();
require 'tts_config.php';

// 1. SECURITY: Must be Admin
if (!isset($_SESSION['is_staff']) || $_SESSION['is_staff'] != 1) {
    die("Access Denied");
}

if (isset($_GET['type']) && isset($_GET['id'])) {
    $id = $_GET['id'];
    $type = $_GET['type'];

    if ($type == 'user') {
        // Prevent deleting yourself
        if ($id == $_SESSION['user_id']) { die("Cannot delete yourself."); }

        // Delete User (Cascades to Profile, Recipes, etc. automatically if foreign keys set correctly)
        // If not set to cascade in SQL, we delete manually just in case:
        $conn->query("DELETE FROM recipes WHERE user_id = $id");
        $conn->query("DELETE FROM profiles WHERE user_id = $id");
        $stmt = $conn->prepare("DELETE FROM users WHERE user_id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        
        header("Location: admin_users.php");

    } elseif ($type == 'recipe') {
        // Delete Recipe
        $stmt = $conn->prepare("DELETE FROM recipes WHERE recipe_id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        
        header("Location: admin_recipes.php");
    }
} else {
    header("Location: admin_dashboard.php");
}
?>