<?php
session_start();
require 'tts_config.php';

if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }
$user_id = $_SESSION['user_id'];

// --- PAGINATION SETTINGS ---
$results_per_page = 8;
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $results_per_page;

// --- 1. COUNT USER'S RECIPES ---
$count_sql = "SELECT COUNT(*) as total FROM recipes WHERE user_id = ?";
$count_stmt = $conn->prepare($count_sql);
$count_stmt->bind_param("i", $user_id);
$count_stmt->execute();
$total_rows = $count_stmt->get_result()->fetch_assoc()['total'];
$total_pages = ceil($total_rows / $results_per_page);

// --- 2. FETCH RECIPES WITH LIMIT ---
$sql = "SELECT * FROM recipes WHERE user_id = ? ORDER BY date_posted DESC LIMIT ?, ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("iii", $user_id, $offset, $results_per_page);
$stmt->execute();
$result = $stmt->get_result();

// FETCH AVATAR
$avatar = 'https://via.placeholder.com/40';
$u_stmt = $conn->prepare("SELECT image FROM profiles WHERE user_id = ?");
$u_stmt->bind_param("i", $user_id);
$u_stmt->execute();
if ($r = $u_stmt->get_result()->fetch_assoc()) { if(!empty($r['image'])) $avatar = $r['image']; }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Recipes | Thyme to Share</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="home.css">
    <style>
        /* --- HEADER & NAV FIXES --- */
        nav {
            height: 70px;
            padding: 0 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-sizing: border-box;
        }
        .nav-brand {
            text-decoration: none !important;
            transition: text-shadow 0.3s ease;
        }
        .nav-brand:hover {
            text-decoration: none !important;
            text-shadow: 0 0 10px rgba(255, 255, 255, 0.9);
        }

        /* CLICK Dropdown Logic */
        .user-menu {
            position: relative;
            height: 100%;
            display: flex;
            align-items: center;
            cursor: pointer;
        }
        .user-trigger {
            display: flex;
            align-items: center;
            gap: 10px;
            user-select: none;
        }
        .dropdown-content {
            display: none;
            position: absolute;
            top: 70px;
            right: 0;
            background-color: white;
            min-width: 160px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.2);
            border-radius: 0 0 5px 5px;
            z-index: 1000;
        }
        .show { display: block; }

        .pagination { margin-top: 30px; text-align: center; display: flex; justify-content: center; gap: 5px; }
        .page-link { padding: 8px 12px; border: 1px solid #ddd; color: #333; text-decoration: none; border-radius: 4px; transition: 0.3s; }
        .page-link:hover { background-color: #f1f1f1; }
        .page-link.active { background-color: #ff7e54; color: white; border-color: #ff7e54; }
    </style>
</head>
<body>

    <nav>
        <a href="home.php" class="nav-brand">Thyme to Share</a>
        <div class="user-menu" onclick="toggleDropdown()">
            <div class="user-trigger">
                <span><?php echo htmlspecialchars($_SESSION['username']); ?></span>
                <img src="<?php echo $avatar; ?>" class="user-avatar-small">
                </div>
            <div id="myDropdown" class="dropdown-content">
                <a href="profile.php">My Profile</a>
                <a href="add-updaterecipe.php">Add Recipe</a>
                <a href="myrecipes.php">My Recipes</a>
                <a href="favorites.php">My Favorites</a>
                <a href="logout.php" style="color:red;">Signout</a>
            </div>
        </div>
    </nav>

    <main>
        <a href="home.php" style="text-decoration:none; color:#555; display:inline-block; margin-bottom:15px;">← Back to Home</a>

        <div class="page-header">
            <h2>My Recipes</h2>
            <p>Recipes you have shared with the world</p>
        </div>

        <div class="recipe-grid">
            <?php
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    $image = !empty($row['featured_image']) ? $row['featured_image'] : 'https://via.placeholder.com/300x200';
                    $title = htmlspecialchars($row['title']);
                    $id = $row['recipe_id'];
                    
                    echo "
                    <div class='card'>
                        <img src='$image' style='width:100%; height:180px; object-fit:cover;'>
                        <h3>$title</h3>
                        <p style='color:#666; font-size:0.9em;'>Status: Published</p>
                        
                        <div style='display:flex; gap:5px; margin-top:10px;'>
                            <a href='recipedetail.php?id=$id' class='btn' style='flex:1;'>View</a>
                            <a href='add-updaterecipe.php?id=$id' class='btn' style='background:#2196F3; flex:1;'>Edit</a>
                            <a href='delete_recipe.php?id=$id' class='btn' style='background:#f44336; flex:1;' onclick=\"return confirm('Are you sure you want to delete this recipe?');\">Delete</a>
                        </div>
                    </div>";
                }
            } else { echo "<p style='text-align:center; width:100%;'>You haven't posted any recipes yet.</p>"; }
            ?>
        </div>

        <?php if ($total_pages > 1): ?>
        <div class="pagination">
            <?php if ($page > 1): ?>
                <a href="myrecipes.php?page=<?php echo $page - 1; ?>" class="page-link">&laquo; Prev</a>
            <?php endif; ?>

            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <a href="myrecipes.php?page=<?php echo $i; ?>" class="page-link <?php echo ($i == $page) ? 'active' : ''; ?>"><?php echo $i; ?></a>
            <?php endfor; ?>

            <?php if ($page < $total_pages): ?>
                <a href="myrecipes.php?page=<?php echo $page + 1; ?>" class="page-link">Next &raquo;</a>
            <?php endif; ?>
        </div>
        <?php endif; ?>

    </main>

    <footer><p>&copy; 2026 Thyme to Share</p></footer>
    <script src="main.js"></script>
    <script>
        function toggleDropdown() {
            document.getElementById("myDropdown").classList.toggle("show");
        }
        window.onclick = function(event) {
            if (!event.target.matches('.user-menu') && !event.target.closest('.user-menu')) {
                var dropdowns = document.getElementsByClassName("dropdown-content");
                for (var i = 0; i < dropdowns.length; i++) {
                    var openDropdown = dropdowns[i];
                    if (openDropdown.classList.contains('show')) {
                        openDropdown.classList.remove('show');
                    }
                }
            }
        }
    </script>
</body>
</html>