<?php
session_start();
require 'tts_config.php';

// UX Feature: If user is already logged in, skip this page and go to Home
if (isset($_SESSION['user_id'])) {
    header("Location: home.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome | Thyme to Share</title>
    <link rel="stylesheet" href="style.css">
    <style>
        /* Specific Styles for the Hero/Landing Section */
        body {
            margin: 0;
            padding: 0;
            font-family: sans-serif;
            height: 100vh;
            overflow: hidden; /* Prevents scrollbars */
        }

        .hero {
            /* Dark overlay + Background Image */
            background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('https://t3.ftcdn.net/jpg/00/87/64/82/360_F_87648201_jO23xggA2W2EjCdfqCTqliX9typRG9rp.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            
            height: 100%;
            width: 100%;
            
            display: flex;
            justify-content: center;
            align-items: center;
            text-align: center;
            color: white;
            position: relative;
        }

        .hero-content {
            max-width: 800px;
            padding: 20px;
            animation: fadeIn 1.5s ease;
        }

        .hero h1 {
            font-size: 4rem;
            margin-bottom: 20px;
            text-shadow: 0 4px 10px rgba(0,0,0,0.5);
            font-weight: 800;
        }

        .hero p {
            font-size: 1.5rem;
            margin-bottom: 50px;
            opacity: 0.95;
            text-shadow: 0 2px 4px rgba(0,0,0,0.5);
        }

        .hero-buttons {
            display: flex;
            gap: 25px;
            justify-content: center;
        }

        /* Large Hero Buttons */
        .btn-hero {
            padding: 15px 50px;
            border-radius: 30px;
            font-weight: bold;
            text-decoration: none;
            font-size: 1.2rem;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        
        .btn-hero:hover {
            transform: translateY(-3px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.4);
        }

        .btn-primary {
            background-color: #ff7e54;
            color: white;
            border: 2px solid #ff7e54;
        }

        .btn-outline {
            background-color: transparent;
            border: 2px solid white;
            color: white;
        }

        .btn-outline:hover {
            background-color: white;
            color: #ff7e54;
        }
        
        /* Copyright at bottom */
        .landing-footer {
            position: absolute;
            bottom: 20px;
            width: 100%;
            text-align: center;
            color: rgba(255,255,255,0.6);
            font-size: 0.9rem;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>

    <div class="hero">
        <div class="hero-content">
            <h1>Welcome to Thyme to Share</h1>
            <p>Your go-to place for discovering, saving, and sharing amazing recipes.</p>
            
            <div class="hero-buttons">
                <a href="signup.php" class="btn-hero btn-primary">Sign Up</a>
                <a href="login.php" class="btn-hero btn-outline">Login</a>
            </div>
        </div>
        
        <div class="landing-footer">
            &copy; 2026 Thyme to Share
        </div>
    </div>

</body>
</html>