<?php
session_start();
require 'tts_config.php';

if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }
$user_id = $_SESSION['user_id'];

$msg = "";
$msg_color = "";
$active_tab = isset($_POST['active_tab']) ? $_POST['active_tab'] : 'settings';

// --- 1. HANDLE PHOTO UPLOAD ---
if (isset($_FILES['profile_photo']) && $_FILES['profile_photo']['error'] == 0) {
    $target_dir = "uploads/";
    if (!file_exists($target_dir)) mkdir($target_dir, 0777, true);
    $filename = time() . "_" . basename($_FILES["profile_photo"]["name"]);
    $target_file = $target_dir . $filename;
    
    if(getimagesize($_FILES["profile_photo"]["tmp_name"]) !== false) {
        if (move_uploaded_file($_FILES["profile_photo"]["tmp_name"], $target_file)) {
            $stmt = $conn->prepare("UPDATE profiles SET image = ? WHERE user_id = ?");
            $stmt->bind_param("si", $target_file, $user_id);
            $stmt->execute();
            $msg = "Photo updated successfully!"; $msg_color = "green";
        } else { $msg = "Error uploading file."; $msg_color = "red"; }
    } else { $msg = "File is not an image."; $msg_color = "red"; }
}

// --- 2. HANDLE GENERAL SETTINGS UPDATE ---
if (isset($_POST['update_general'])) {
    $username = trim($_POST['username']); 
    $fname = trim($_POST['first_name']);
    $lname = trim($_POST['last_name']);
    $email = trim($_POST['email']);

    if (empty($username) || empty($fname) || empty($lname) || empty($email)) {
        $msg = "All fields are required."; $msg_color = "red";
    } else {
        $stmt = $conn->prepare("UPDATE users SET username=?, first_name=?, last_name=?, email=? WHERE user_id=?");
        $stmt->bind_param("ssssi", $username, $fname, $lname, $email, $user_id);
        
        try {
            if ($stmt->execute()) {
                $_SESSION['username'] = $username; 
                $msg = "General settings updated!"; $msg_color = "green";
            } else {
                $msg = "Error updating details."; $msg_color = "red";
            }
        } catch (mysqli_sql_exception $e) {
            $msg = "Error: Username or Email is already taken."; $msg_color = "red";
        }
    }
    $active_tab = 'settings'; 
}

// --- 3. HANDLE PASSWORD UPDATE ---
if (isset($_POST['update_password'])) {
    $current_pass = $_POST['current_password'];
    $new_pass     = $_POST['new_password'];
    $confirm_pass = $_POST['confirm_password'];

    $sql = "SELECT password FROM users WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $userData = $stmt->get_result()->fetch_assoc();

    if (password_verify($current_pass, $userData['password'])) {
        if ($new_pass === $confirm_pass && !empty($new_pass)) {
            $new_hash = password_hash($new_pass, PASSWORD_DEFAULT);
            $update_sql = "UPDATE users SET password = ? WHERE user_id = ?";
            $update_stmt = $conn->prepare($update_sql);
            $update_stmt->bind_param("si", $new_hash, $user_id);
            if ($update_stmt->execute()) {
                $msg = "Password changed successfully!"; $msg_color = "green";
            }
        } else { $msg = "New passwords do not match or are empty."; $msg_color = "red"; }
    } else { $msg = "Incorrect current password."; $msg_color = "red"; }
    $active_tab = 'password'; 
}

// --- 4. FETCH LATEST USER DATA ---
$sql = "SELECT users.*, profiles.image FROM users JOIN profiles ON users.user_id = profiles.user_id WHERE users.user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

$avatar = !empty($user['image']) ? $user['image'] : 'https://via.placeholder.com/150';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Profile Settings | Thyme to Share</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body { background-color: #f4f7f6; font-family: Arial, sans-serif; }
        
        nav {
            height: 70px;
            padding: 0 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-sizing: border-box;
            background-color: #ff7043;
        }
        .nav-brand {
            text-decoration: none !important;
            transition: text-shadow 0.3s ease;
            color: white;
            font-weight: bold;
            font-size: 1.5rem;
            font-family: Arial, sans-serif;
        }
        .nav-brand:hover { text-shadow: 0 0 10px rgba(255, 255, 255, 0.9); }
        
        .user-menu {
            position: relative;
            height: 100%;
            display: flex;
            align-items: center;
            cursor: pointer;
            color: white;
            font-family: Arial, sans-serif;
            font-weight: bold;
        }
        .user-trigger {
            display: flex;
            align-items: center;
            gap: 10px;
            user-select: none;
        }
        .dropdown-content {
            display: none;
            position: absolute;
            top: 70px;
            right: 0;
            background-color: white;
            min-width: 160px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.2);
            border-radius: 0 0 5px 5px;
            z-index: 1000;
        }
        .dropdown-content a {
            color: #333;
            text-decoration: none;
            display: block;
            padding: 10px 15px;
            font-weight: normal;
        }
        .dropdown-content a:hover { background-color: #f1f1f1; }
        .show { display: block; }

        .profile-header {
            text-align: center;
            padding: 30px 20px;
            background: white;
            margin-bottom: 20px;
            border-bottom: 1px solid #eee;
        }
        .profile-img-large {
            width: 120px; height: 120px;
            border-radius: 50%; object-fit: cover;
            border: 3px solid #ff7e54;
        }
        .profile-name { font-size: 1.5rem; margin: 10px 0 5px; }
        .profile-email { color: #777; margin: 0 0 15px; }
        
        .upload-btn-wrapper { position: relative; overflow: hidden; display: inline-block; }
        .btn-upload { 
            border: 1px solid #ccc; color: #555; background-color: white; 
            padding: 8px 20px; border-radius: 5px; font-size: 0.9rem; font-weight: bold; cursor: pointer;
        }
        .upload-btn-wrapper input[type=file] {
            font-size: 100px; position: absolute; left: 0; top: 0; opacity: 0; cursor: pointer;
        }

        .container-tabs { max-width: 900px; margin: 0 auto; background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.05); }
        .tabs-nav { display: flex; border-bottom: 1px solid #eee; background: #fafafa; }
        .tab-link {
            padding: 15px 25px;
            cursor: pointer;
            text-decoration: none;
            color: #555;
            font-weight: 600;
            border-bottom: 3px solid transparent;
            transition: 0.3s;
        }
        .tab-link:hover { background: #f0f0f0; }
        .tab-link.active { border-bottom-color: #ff7e54; color: #ff7e54; background: white; }
        
        .tab-content { padding: 30px; display: none; }
        .tab-content.active { display: block; }
        .tab-title { margin-top: 0; margin-bottom: 20px; font-size: 1.3rem; color: #333; }

        .form-row { display: flex; gap: 20px; margin-bottom: 20px; }
        .form-col { flex: 1; }
        .form-label { display: block; margin-bottom: 8px; font-weight: 600; color: #555; }
        .form-input { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px; box-sizing: border-box; }
        .btn-save { background-color: #ff7e54; color: white; border: none; padding: 12px 30px; border-radius: 5px; font-weight: bold; cursor: pointer; }
        .btn-save:hover { background-color: #e66d46; }

        .alert-msg { padding: 15px; margin-bottom: 20px; border-radius: 5px; text-align: center; }

        /* PASSWORD REVEAL */
        .password-wrapper { position: relative; width: 100%; }
        .password-wrapper input { padding-right: 40px; }
        .toggle-password {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            cursor: pointer;
            color: #777;
            padding: 0;
            display: flex;
            align-items: center;
            outline: none;
        }
        .toggle-password:hover { color: #333; }
        .toggle-password svg { width: 20px; height: 20px; }
        input[type="password"]::-ms-reveal, input[type="password"]::-ms-clear { display: none; }
    </style>
</head>
<body>

    <nav>
        <a href="home.php" class="nav-brand">Thyme to Share</a>
        <div class="user-menu" onclick="toggleDropdown()">
            <div class="user-trigger">
                <span><?php echo htmlspecialchars($_SESSION['username']); ?></span>
                <img src="<?php echo $avatar; ?>" class="user-avatar-small">
                </div>
            <div id="myDropdown" class="dropdown-content">
                <a href="profile.php">My Profile</a>
                <a href="add-updaterecipe.php">Add Recipe</a>
                <a href="myrecipes.php">My Recipes</a>
                <a href="favorites.php">My Favorites</a>
                <a href="logout.php" style="color:red;">Signout</a>
            </div>
        </div>
    </nav>

    <main style="padding: 0; max-width: 100%;">
        
        <div style="max-width: 900px; margin: 20px auto 0; padding: 0 20px;">
            <a href="home.php" style="text-decoration:none; color:#555; display:inline-block; margin-bottom:15px;">← Back to Home</a>
        </div>

        <div class="profile-header">
            <img src="<?php echo $avatar; ?>" alt="Profile" class="profile-img-large">
            <h1 class="profile-name"><?php echo htmlspecialchars($user['username']); ?></h1>
            <p class="profile-email"><?php echo htmlspecialchars($user['email']); ?></p>
            
            <form action="profile.php" method="POST" enctype="multipart/form-data" id="photoForm">
                <div class="upload-btn-wrapper">
                    <button class="btn-upload">Upload Photo</button>
                    <input type="file" name="profile_photo" accept="image/*" onchange="document.getElementById('photoForm').submit();">
                </div>
            </form>
        </div>

        <div class="container-tabs">
            <div class="tabs-nav">
                <a href="myrecipes.php" class="tab-link">My Recipes</a>
                <div class="tab-link <?php if($active_tab == 'settings') echo 'active'; ?>" onclick="openTab(event, 'settingsTab')">General Settings</div>
                <div class="tab-link <?php if($active_tab == 'password') echo 'active'; ?>" onclick="openTab(event, 'passwordTab')">Change Password</div>
            </div>

            <div style="padding: 20px;">
                <?php if($msg): ?>
                    <div class="alert-msg" style="background-color: <?php echo $msg_color == 'green' ? '#d4edda' : '#f8d7da'; ?>; color: <?php echo $msg_color == 'green' ? '#155724' : '#721c24'; ?>;">
                        <?php echo $msg; ?>
                    </div>
                <?php endif; ?>
            </div>

            <div id="settingsTab" class="tab-content <?php if($active_tab == 'settings') echo 'active'; ?>">
                <h3 class="tab-title">General Info</h3>
                <form action="profile.php" method="POST">
                    <input type="hidden" name="active_tab" value="settings">
                    
                    <div class="form-row">
                        <div class="form-col">
                            <label class="form-label">Username</label>
                            <input type="text" name="username" class="form-input" value="<?php echo htmlspecialchars($user['username']); ?>" required>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-col">
                            <label class="form-label">First Name</label>
                            <input type="text" name="first_name" class="form-input" value="<?php echo htmlspecialchars($user['first_name']); ?>" required>
                        </div>
                        <div class="form-col">
                            <label class="form-label">Last Name</label>
                            <input type="text" name="last_name" class="form-input" value="<?php echo htmlspecialchars($user['last_name']); ?>" required>
                        </div>
                    </div>
                    <div class="form-row">
                         <div class="form-col">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" class="form-input" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                        </div>
                    </div>
                    <button type="submit" name="update_general" class="btn-save">Save changes</button>
                </form>
            </div>

            <div id="passwordTab" class="tab-content <?php if($active_tab == 'password') echo 'active'; ?>">
                <h3 class="tab-title">Change Password</h3>
                 <form method="POST" action="profile.php">
                    <input type="hidden" name="active_tab" value="password">
                    
                    <div class="form-row">
                        <div class="form-col">
                            <label class="form-label">Current Password</label>
                            <div class="password-wrapper">
                                <input type="password" name="current_password" id="currPass" class="form-input" required>
                                <button type="button" class="toggle-password" onclick="togglePassword('currPass')">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
                                </button>
                            </div>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-col">
                            <label class="form-label">New Password</label>
                            <div class="password-wrapper">
                                <input type="password" name="new_password" id="newPass" class="form-input" required>
                                <button type="button" class="toggle-password" onclick="togglePassword('newPass')">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
                                </button>
                            </div>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-col">
                            <label class="form-label">Confirm Password</label>
                            <div class="password-wrapper">
                                <input type="password" name="confirm_password" id="confPass" class="form-input" required>
                                <button type="button" class="toggle-password" onclick="togglePassword('confPass')">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
                                </button>
                            </div>
                        </div>
                    </div>

                    <button type="submit" name="update_password" class="btn-save">Update Password</button>
                </form>
            </div>

        </div>
    </main>

    <footer><p>&copy; 2026 Thyme to Share</p></footer>
    <script src="main.js"></script>
    <script>
        function openTab(evt, tabName) {
            var i, tabcontent, tablinks;
            tabcontent = document.getElementsByClassName("tab-content");
            for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].classList.remove("active");
            }
            tablinks = document.getElementsByClassName("tab-link");
            for (i = 0; i < tablinks.length; i++) {
                tablinks[i].classList.remove("active");
            }
            document.getElementById(tabName).classList.add("active");
            evt.currentTarget.classList.add("active");
        }

        function toggleDropdown() {
            document.getElementById("myDropdown").classList.toggle("show");
        }
        window.onclick = function(event) {
            if (!event.target.matches('.user-menu') && !event.target.closest('.user-menu')) {
                var dropdowns = document.getElementsByClassName("dropdown-content");
                for (var i = 0; i < dropdowns.length; i++) {
                    var openDropdown = dropdowns[i];
                    if (openDropdown.classList.contains('show')) {
                        openDropdown.classList.remove('show');
                    }
                }
            }
        }

        function togglePassword(inputId) {
            const input = document.getElementById(inputId);
            if (input.type === "password") {
                input.type = "text";
            } else {
                input.type = "password";
            }
        }
    </script>
</body>
</html>