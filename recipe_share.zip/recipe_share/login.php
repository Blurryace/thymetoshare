<?php
session_start();
require 'tts_config.php';

$email_val = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // 1. SELECT is_staff too
    $stmt = $conn->prepare("SELECT user_id, username, password, is_staff FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        if (password_verify($password, $row['password'])) {
            $_SESSION['user_id'] = $row['user_id'];
            $_SESSION['username'] = $row['username'];
            
            // 2. STORE ADMIN STATUS IN SESSION
            $_SESSION['is_staff'] = $row['is_staff']; 

            // Redirect: If Admin, go to Dashboard. If User, go to Home.
            if ($row['is_staff'] == 1) {
                header("Location: admin_dashboard.php");
            } else {
                header("Location: home.php");
            }
            exit();
        } else { 
            $error = "Invalid password."; 
            $email_val = htmlspecialchars($email);
        }
    } else { 
        $error = "No account found."; 
        $email_val = ""; 
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login | Thyme to Share</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="login.css">
    <style>
        /* Hide default browser password reveal to prevent overlap */
        input[type="password"]::-ms-reveal,
        input[type="password"]::-ms-clear {
            display: none;
        }

        /* Center the Page */
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-color: #f4f4f4;
            margin: 0;
            font-family: sans-serif;
        }

        /* Card Style */
        .card {
            background: white;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 350px;
            text-align: center;
        }

        /* Input Fields */
        .form-group { margin-bottom: 20px; text-align: left; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: bold; color: #333; }
        .form-group input { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; }

        /* Password Reveal */
        .password-wrapper { position: relative; width: 100%; }
        .password-wrapper input { padding-right: 40px; }
        .toggle-password {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            cursor: pointer;
            color: #777;
            padding: 0;
            display: flex;
            align-items: center;
            outline: none;
        }
        .toggle-password:hover { color: #333; }
        .toggle-password svg { width: 20px; height: 20px; }

        /* Button */
        .btn {
            background-color: #ff7e54 !important;
            color: white !important;
            border: none;
            width: 100%;
            padding: 12px;
            font-weight: bold;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s;
        }
        .btn:hover { background-color: #e66d46 !important; }
        
        /* Links */
        a { color: #ff7e54; text-decoration: none; }
        a:hover { text-decoration: underline; }
    </style>
</head>
<body>

    <div class="card">
        <h2 style="margin-top:0; color:#333;">Login</h2>
        
        <?php if(isset($error)) echo "<p style='color:red;'>$error</p>"; ?>
        
        <form action="login.php" method="POST">
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" value="<?php echo $email_val; ?>" required>
            </div>
            
            <div class="form-group">
                <label>Password</label>
                <div class="password-wrapper">
                    <input type="password" name="password" id="passwordInput" required>
                    <button type="button" class="toggle-password" onclick="togglePassword()">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
                    </button>
                </div>
            </div>
            
            <button type="submit" class="btn">Login</button>
        </form>
        
        <p style="margin-top:20px; color:#666;">Don't have an account? <a href="signup.php">Sign Up</a></p>
        <p><a href="index.php" style="color: #999; font-size: 0.9em;">← Back to Home</a></p>
    </div>

    <script>
        function togglePassword() {
            const input = document.getElementById("passwordInput");
            if (input.type === "password") {
                input.type = "text";
            } else {
                input.type = "password";
            }
        }
    </script>
</body>
</html>