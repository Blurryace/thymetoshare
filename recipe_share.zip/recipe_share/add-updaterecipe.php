<?php
session_start();
require 'tts_config.php';

if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }

$user_id = $_SESSION['user_id'];
$is_editing = false;
$recipe_id = "";

// Initialize variables
$title = $excerpt = $about = $category = $prep_time = $cooking_time = $servings = $ingredients = $instructions = "";

// FETCH USER AVATAR (For the Navbar)
$avatar = 'https://via.placeholder.com/40';
$u_stmt = $conn->prepare("SELECT image FROM profiles WHERE user_id = ?");
$u_stmt->bind_param("i", $user_id);
$u_stmt->execute();
if ($r = $u_stmt->get_result()->fetch_assoc()) { if(!empty($r['image'])) $avatar = $r['image']; }

// CHECK IF EDITING
if (isset($_GET['id'])) {
    $is_editing = true;
    $recipe_id = $_GET['id'];
    $stmt = $conn->prepare("SELECT * FROM recipes WHERE recipe_id = ? AND user_id = ?");
    $stmt->bind_param("ii", $recipe_id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $title = $row['title'];
        $excerpt = $row['excerpt'];
        $about = $row['about'];
        $category = $row['category'];
        $prep_time = $row['prep_time'];
        $cooking_time = $row['cooking_time'];
        $servings = $row['servings'];
        $ingredients = $row['ingredients'];
        $instructions = $row['instructions'];
    } else { die("Permission denied."); }
}

// HANDLE SUBMIT
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $excerpt = $_POST['excerpt'];
    $about = $_POST['about'];
    $category = $_POST['category'];
    $prep_time = $_POST['prep_time'];
    $cooking_time = $_POST['cooking_time'];
    $servings = $_POST['servings'];
    $ingredients = $_POST['ingredients'];
    $instructions = $_POST['instructions'];

    // 1. Handle Image Upload
    $image_path = null; 
    if (!empty($_FILES["featured_image"]["name"])) {
        $target_dir = "uploads/";
        if (!file_exists($target_dir)) mkdir($target_dir, 0777, true);
        $image_path = $target_dir . basename($_FILES["featured_image"]["name"]);
        move_uploaded_file($_FILES["featured_image"]["tmp_name"], $image_path);
    }

    if (isset($_POST['recipe_id']) && !empty($_POST['recipe_id'])) {
        // --- UPDATE EXISTING RECIPE ---
        $update_id = $_POST['recipe_id'];
        
        $image_sql_part = "";
        if ($image_path) {
            $image_sql_part = ", featured_image = '$image_path'";
        }

        $sql = "UPDATE recipes SET title=?, excerpt=?, about=?, category=?, prep_time=?, cooking_time=?, servings=?, ingredients=?, instructions=? $image_sql_part WHERE recipe_id=? AND user_id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssiiissii", $title, $excerpt, $about, $category, $prep_time, $cooking_time, $servings, $ingredients, $instructions, $update_id, $user_id);

    } else {
        // --- INSERT NEW RECIPE ---
        
        if ($image_path) {
            $img_to_save = $image_path;
        } else {
            $img_to_save = "tts.png";
        }

        $sql = "INSERT INTO recipes (user_id, title, excerpt, about, category, prep_time, cooking_time, servings, ingredients, instructions, featured_image) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("issssiiisss", $user_id, $title, $excerpt, $about, $category, $prep_time, $cooking_time, $servings, $ingredients, $instructions, $img_to_save);
    }

    if ($stmt->execute()) { header("Location: myrecipes.php"); }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo $is_editing ? "Edit" : "Add"; ?> Recipe | Thyme to Share</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="add-updaterecipe.css">
    <style>
        /* --- HEADER & NAV FIXES --- */
        nav {
            height: 70px;
            padding: 0 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-sizing: border-box;
        }
        .nav-brand {
            text-decoration: none !important;
            transition: text-shadow 0.3s ease;
        }
        .nav-brand:hover {
            text-decoration: none !important;
            text-shadow: 0 0 10px rgba(255, 255, 255, 0.9);
        }

        /* CLICK Dropdown Logic */
        .user-menu {
            position: relative;
            height: 100%;
            display: flex;
            align-items: center;
            cursor: pointer;
        }
        .user-trigger {
            display: flex;
            align-items: center;
            gap: 10px;
            user-select: none;
        }
        .dropdown-content {
            display: none;
            position: absolute;
            top: 70px;
            right: 0;
            background-color: white;
            min-width: 160px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.2);
            border-radius: 0 0 5px 5px;
            z-index: 1000;
        }
        .show { display: block; }
    </style>
</head>
<body>

    <nav>
        <a href="home.php" class="nav-brand">Thyme to Share</a>
        <div class="user-menu" onclick="toggleDropdown()">
            <div class="user-trigger">
                <span><?php echo htmlspecialchars($_SESSION['username']); ?></span>
                <img src="<?php echo $avatar; ?>" class="user-avatar-small">
                </div>
            <div id="myDropdown" class="dropdown-content">
                <a href="profile.php">My Profile</a>
                <a href="add-updaterecipe.php">Add Recipe</a>
                <a href="myrecipes.php">My Recipes</a>
                <a href="favorites.php">My Favorites</a>
                <a href="logout.php" style="color:red;">Signout</a>
            </div>
        </div>
    </nav>

    <main>
        <div class="form-container">
            <a href="home.php" style="text-decoration:none; color:#555; display:inline-block; margin-bottom:15px;">← Back to Home</a>
            
            <h2><?php echo $is_editing ? "Edit Recipe" : "Add a New Recipe"; ?></h2>
            <form action="add-updaterecipe.php" method="POST" enctype="multipart/form-data">
                <?php if($is_editing): ?><input type="hidden" name="recipe_id" value="<?php echo $recipe_id; ?>"><?php endif; ?>

                <div class="form-group">
                    <label>Featured Image</label>
                    <input type="file" name="featured_image" accept="image/*">
                    <?php if(!$is_editing) echo "<small style='color:#666;'>No image? We'll use the default Thyme to Share photo.</small>"; ?>
                </div>

                <div class="form-group"><label>Title</label><input type="text" name="title" value="<?php echo htmlspecialchars($title); ?>" required placeholder="e.g. Spicy Chicken Pasta"></div>
                <div class="form-group"><label>Short Description</label><input type="text" name="excerpt" value="<?php echo htmlspecialchars($excerpt); ?>" required placeholder="e.g. A quick and easy dinner."></div>
                <div class="form-group"><label>About</label><textarea name="about" rows="3" required placeholder="Tell us the story behind this dish..."><?php echo htmlspecialchars($about); ?></textarea></div>
                
                <div class="form-group">
                    <label>Category</label>
                    <select name="category" style="width:100%; padding:10px; border:1px solid #aaa; border-radius:6px;">
                        <option value="Breakfast" <?php if($category == 'Breakfast') echo 'selected'; ?>>Breakfast</option>
                        <option value="Lunch" <?php if($category == 'Lunch') echo 'selected'; ?>>Lunch</option>
                        <option value="Dinner" <?php if($category == 'Dinner') echo 'selected'; ?>>Dinner</option>
                        <option value="Dessert" <?php if($category == 'Dessert') echo 'selected'; ?>>Dessert</option>
                        <option value="Snack" <?php if($category == 'Snack') echo 'selected'; ?>>Snack</option>
                        <option value="Drink" <?php if($category == 'Drink') echo 'selected'; ?>>Drink</option>
                        <option value="Any" <?php if($category == 'Any') echo 'selected'; ?>>Any</option>
                    </select>
                </div>
                
                <div style="display:flex; gap:30px;">
                    <div class="form-group" style="flex:1;"><label>Prep Time</label><input type="number" name="prep_time" value="<?php echo $prep_time; ?>" min="0" placeholder="mins"></div>
                    <div class="form-group" style="flex:1;"><label>Cook Time</label><input type="number" name="cooking_time" value="<?php echo $cooking_time; ?>" min="0" placeholder="mins"></div>
                    <div class="form-group" style="flex:1;"><label>Servings</label><input type="number" name="servings" value="<?php echo $servings; ?>" min="0" placeholder="people"></div>
                </div>

                <div class="form-group"><label>Ingredients</label><textarea name="ingredients" rows="5" required placeholder="1 cup Rice&#10;2 cloves Garlic"><?php echo htmlspecialchars($ingredients); ?></textarea></div>
                <div class="form-group"><label>Instructions</label><textarea name="instructions" rows="6" required placeholder="1. Boil water..."><?php echo htmlspecialchars($instructions); ?></textarea></div>

                <button type="submit" class="btn" style="width:100%;"><?php echo $is_editing ? "Update Recipe" : "Save Recipe"; ?></button>
            </form>
        </div>
    </main>

    <footer><p>&copy; 2026 Thyme to Share</p></footer>
    <script src="main.js"></script>
    <script>
        function toggleDropdown() {
            document.getElementById("myDropdown").classList.toggle("show");
        }
        window.onclick = function(event) {
            if (!event.target.matches('.user-menu') && !event.target.closest('.user-menu')) {
                var dropdowns = document.getElementsByClassName("dropdown-content");
                for (var i = 0; i < dropdowns.length; i++) {
                    var openDropdown = dropdowns[i];
                    if (openDropdown.classList.contains('show')) {
                        openDropdown.classList.remove('show');
                    }
                }
            }
        }
    </script>
</body>
</html>