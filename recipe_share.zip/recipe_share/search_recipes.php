<?php
require 'tts_config.php';

$search = isset($_POST['search']) ? $_POST['search'] : '';
$category = isset($_POST['category']) ? $_POST['category'] : '';

// 1. UPDATED QUERY: Matches start of title OR start of any word in title (space + letter)
$sql = "SELECT recipes.*, users.username FROM recipes 
        JOIN users ON recipes.user_id = users.user_id 
        WHERE (title LIKE ? OR title LIKE ?)";
$types = "ss";

// 2. CHECK: "A..." OR "... A..."
$params = ["$search%", "% $search%"]; 

if (!empty($category)) {
    $sql .= " AND category = ?";
    $types .= "s";
    $params[] = $category;
}

$sql .= " ORDER BY date_posted DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

// Output HTML directly
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $img = !empty($row['featured_image']) ? $row['featured_image'] : 'https://via.placeholder.com/300x200';
        $title = htmlspecialchars($row['title']);
        $username = htmlspecialchars($row['username']);
        $id = $row['recipe_id'];

        echo "
        <div class='card'>
            <img src='$img' style='width:100%; height:180px; object-fit:cover;'>
            <h3>$title</h3>
            <p>By $username</p>
            <a href='recipedetail.php?id=$id' class='btn'>View Recipe</a>
        </div>";
    }
} else {
    echo "<p style='text-align:center; width:100%; color:#666;'>No recipes found matching your search.</p>";
}
?>