<?php
session_start();
require 'tts_config.php';

// --- PAGINATION SETTINGS ---
$results_per_page = 8;
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $results_per_page;

// --- SEARCH PARAMETERS ---
$search = isset($_GET['search']) ? $_GET['search'] : '';
$category = isset($_GET['category']) ? $_GET['category'] : '';

// --- 1. GET TOTAL RECIPES COUNT (For Pagination) ---
$count_sql = "SELECT COUNT(*) as total FROM recipes 
              JOIN users ON recipes.user_id = users.user_id 
              WHERE (title LIKE ? OR title LIKE ?)";
$types = "ss";
$params = ["$search%", "% $search%"]; 

if (!empty($category)) {
    $count_sql .= " AND category = ?";
    $types .= "s";
    $params[] = $category;
}

$count_stmt = $conn->prepare($count_sql);
$count_stmt->bind_param($types, ...$params);
$count_stmt->execute();
$total_rows = $count_stmt->get_result()->fetch_assoc()['total'];
$total_pages = ceil($total_rows / $results_per_page);

// --- 2. GET RECIPES FOR CURRENT PAGE ---
$sql = "SELECT recipes.*, users.username FROM recipes 
        JOIN users ON recipes.user_id = users.user_id 
        WHERE (title LIKE ? OR title LIKE ?)";

$types = "ss";
$params = ["$search%", "% $search%"]; 

if (!empty($category)) {
    $sql .= " AND category = ?";
    $types .= "s";
    $params[] = $category;
}

$sql .= " ORDER BY date_posted DESC LIMIT ?, ?";
$types .= "ii";
$params[] = $offset;
$params[] = $results_per_page;

$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

// --- FETCH USER AVATAR ---
$avatar = 'https://via.placeholder.com/40';
if (isset($_SESSION['user_id'])) {
    $u_id = $_SESSION['user_id'];
    $u_stmt = $conn->prepare("SELECT image FROM profiles WHERE user_id = ?");
    $u_stmt->bind_param("i", $u_id);
    $u_stmt->execute();
    if ($r = $u_stmt->get_result()->fetch_assoc()) { if(!empty($r['image'])) $avatar = $r['image']; }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Thyme to Share</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="home.css">
    <style>
        /* --- HEADER & NAV FIXES --- */
        nav {
            height: 70px;
            padding: 0 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-sizing: border-box;
        }
        .nav-brand {
            text-decoration: none !important;
            transition: text-shadow 0.3s ease;
        }
        .nav-brand:hover {
            text-decoration: none !important;
            text-shadow: 0 0 10px rgba(255, 255, 255, 0.9);
        }

        /* CLICK Dropdown Logic */
        .user-menu {
            position: relative;
            height: 100%;
            display: flex;
            align-items: center;
            cursor: pointer;
        }
        .user-trigger {
            display: flex;
            align-items: center;
            gap: 10px;
            user-select: none; /* Prevents text highlighting when clicking fast */
        }
        .dropdown-content {
            display: none; /* Hidden by default */
            position: absolute;
            top: 70px;
            right: 0;
            background-color: white;
            min-width: 160px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.2);
            border-radius: 0 0 5px 5px;
            z-index: 1000;
        }
        
        /* Show class for JS toggle */
        .show { display: block; }

        /* Pagination Styles */
        .pagination { margin-top: 30px; text-align: center; display: flex; justify-content: center; gap: 5px; }
        .page-link { padding: 8px 12px; border: 1px solid #ddd; color: #333; text-decoration: none; border-radius: 4px; transition: 0.3s; }
        .page-link:hover { background-color: #f1f1f1; }
        .page-link.active { background-color: #ff7e54; color: white; border-color: #ff7e54; }
    </style>
</head>
<body>

    <nav>
        <a href="home.php" class="nav-brand">Thyme to Share</a>
        <?php if(isset($_SESSION['user_id'])): ?>
        <div class="user-menu" onclick="toggleDropdown()">
            <div class="user-trigger">
                <span><?php echo htmlspecialchars($_SESSION['username']); ?></span>
                <img src="<?php echo $avatar; ?>" class="user-avatar-small">
            </div>
            <div id="myDropdown" class="dropdown-content">
                <a href="profile.php">My Profile</a>
                <a href="add-updaterecipe.php">Add Recipe</a>
                <a href="myrecipes.php">My Recipes</a>
                <a href="favorites.php">My Favorites</a>
                <a href="logout.php" style="color:red;">Sign out</a>
            </div>
        </div>
        <?php else: ?>
            <a href="login.php" style="color:white; text-decoration:none; font-weight:bold;">Login</a>
        <?php endif; ?>
    </nav>

    <main>
        <form action="home.php" method="GET" class="search-bar" id="searchForm">
            <input type="text" name="search" id="searchInput" placeholder="Search recipes..." value="<?php echo htmlspecialchars($search); ?>" class="search-input">
            
            <select name="category" id="categorySelect" class="search-input" style="width:150px;" onchange="document.getElementById('searchForm').submit();">
                <option value="">All Categories</option>
                <option value="Breakfast" <?php if($category == 'Breakfast') echo 'selected'; ?>>Breakfast</option>
                <option value="Lunch" <?php if($category == 'Lunch') echo 'selected'; ?>>Lunch</option>
                <option value="Dinner" <?php if($category == 'Dinner') echo 'selected'; ?>>Dinner</option>
                <option value="Dessert" <?php if($category == 'Dessert') echo 'selected'; ?>>Dessert</option>
                <option value="Snack" <?php if($category == 'Snack') echo 'selected'; ?>>Snack</option>
                <option value="Drink" <?php if($category == 'Drink') echo 'selected'; ?>>Drink</option>
                <option value="Any" <?php if($category == 'Any') echo 'selected'; ?>>Any</option>
            </select>
            <button type="submit" class="search-btn">Search</button>
        </form>

        <div class="recipe-grid" id="recipeGrid">
            <?php
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    $img = !empty($row['featured_image']) ? $row['featured_image'] : 'https://via.placeholder.com/300x200';
                    echo "<div class='card'>
                        <img src='$img' style='width:100%; height:180px; object-fit:cover;'>
                        <h3>{$row['title']}</h3>
                        <p>By {$row['username']}</p>
                        <a href='recipedetail.php?id={$row['recipe_id']}' class='btn'>View Recipe</a>
                    </div>";
                }
            } else { echo "<p style='text-align:center; width:100%;'>No recipes found.</p>"; }
            ?>
        </div>

        <div id="paginationContainer">
            <?php if ($total_pages > 1): ?>
            <div class="pagination">
                <?php $queryParams = $_GET; ?>

                <?php if ($page > 1): 
                    $queryParams['page'] = $page - 1;
                ?>
                    <a href="home.php?<?php echo http_build_query($queryParams); ?>" class="page-link">&laquo; Prev</a>
                <?php endif; ?>

                <?php for ($i = 1; $i <= $total_pages; $i++): 
                    $queryParams['page'] = $i;
                    $activeClass = ($i == $page) ? 'active' : '';
                ?>
                    <a href="home.php?<?php echo http_build_query($queryParams); ?>" class="page-link <?php echo $activeClass; ?>"><?php echo $i; ?></a>
                <?php endfor; ?>

                <?php if ($page < $total_pages): 
                    $queryParams['page'] = $page + 1;
                ?>
                    <a href="home.php?<?php echo http_build_query($queryParams); ?>" class="page-link">Next &raquo;</a>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>

    </main>

    <footer><p>&copy; 2026 Thyme to Share</p></footer>
    <script src="main.js"></script>

    <script>
        /* --- DROPDOWN TOGGLE SCRIPT --- */
        function toggleDropdown() {
            document.getElementById("myDropdown").classList.toggle("show");
        }

        // Close the dropdown if the user clicks outside of it
        window.onclick = function(event) {
            if (!event.target.matches('.user-menu') && !event.target.closest('.user-menu')) {
                var dropdowns = document.getElementsByClassName("dropdown-content");
                for (var i = 0; i < dropdowns.length; i++) {
                    var openDropdown = dropdowns[i];
                    if (openDropdown.classList.contains('show')) {
                        openDropdown.classList.remove('show');
                    }
                }
            }
        }

        /* --- SEARCH SCRIPT --- */
        const searchInput = document.getElementById('searchInput');
        const categorySelect = document.getElementById('categorySelect');
        const resultsContainer = document.getElementById('recipeGrid');
        const paginationContainer = document.getElementById('paginationContainer');

        function fetchRecipes() {
            const formData = new FormData();
            formData.append('search', searchInput.value);
            formData.append('category', categorySelect.value);

            if(paginationContainer) paginationContainer.style.display = 'none';

            fetch('search_recipes.php', { method: 'POST', body: formData })
            .then(response => response.text())
            .then(html => { resultsContainer.innerHTML = html; })
            .catch(error => console.error('Error:', error));
        }

        searchInput.addEventListener('input', fetchRecipes);
    </script>
</body>
</html>