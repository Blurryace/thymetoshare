<?php
session_start();
require 'tts_config.php';

// 1. Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// 2. Check if an ID was provided
if (isset($_GET['id'])) {
    $recipe_id = $_GET['id'];
    $user_id = $_SESSION['user_id'];

    // 3. Security Check: Delete ONLY if the recipe belongs to the logged-in user
    $stmt = $conn->prepare("DELETE FROM recipes WHERE recipe_id = ? AND user_id = ?");
    $stmt->bind_param("ii", $recipe_id, $user_id);

    if ($stmt->execute()) {
        // Success: Redirect back to the list
        header("Location: myrecipes.php"); 
        exit();
    } else {
        echo "Error deleting record or permission denied.";
    }
} else {
    // If no ID provided, just go back
    header("Location: myrecipes.php");
    exit();
}
?>