<?php
session_start();
require 'tts_config.php';

// 1. Get Recipe ID
if (!isset($_GET['id'])) {
    die("No recipe specified.");
}
$recipe_id = $_GET['id'];

// 2. Fetch Recipe Details
$sql = "SELECT recipes.*, users.username, users.first_name, users.last_name 
        FROM recipes 
        JOIN users ON recipes.user_id = users.user_id 
        WHERE recipes.recipe_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $recipe_id);
$stmt->execute();
$recipe = $stmt->get_result()->fetch_assoc();

if (!$recipe) {
    die("Recipe not found.");
}

// 3. Fetch Current User's Avatar (For the Navbar)
$avatar = 'https://via.placeholder.com/40';
if (isset($_SESSION['user_id'])) {
    $u_id = $_SESSION['user_id'];
    $u_stmt = $conn->prepare("SELECT image FROM profiles WHERE user_id = ?");
    $u_stmt->bind_param("i", $u_id);
    $u_stmt->execute();
    if ($r = $u_stmt->get_result()->fetch_assoc()) { 
        if(!empty($r['image'])) $avatar = $r['image']; 
    }
}

// 4. Check if Favorited
$is_favorited = false;
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $fav_check = $conn->prepare("SELECT * FROM favorites WHERE user_id = ? AND recipe_id = ?");
    $fav_check->bind_param("ii", $user_id, $recipe_id);
    $fav_check->execute();
    if ($fav_check->get_result()->num_rows > 0) {
        $is_favorited = true;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo htmlspecialchars($recipe['title']); ?> | Thyme to Share</title>
    <link rel="stylesheet" href="style.css">
    <style>
        /* --- HEADER & NAV FIXES --- */
        nav {
            height: 70px;
            padding: 0 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-sizing: border-box;
        }
        .nav-brand {
            text-decoration: none !important;
            transition: text-shadow 0.3s ease;
        }
        .nav-brand:hover {
            text-decoration: none !important;
            text-shadow: 0 0 10px rgba(255, 255, 255, 0.9);
        }

        /* CLICK Dropdown Logic */
        .user-menu {
            position: relative;
            height: 100%;
            display: flex;
            align-items: center;
            cursor: pointer;
        }
        .user-trigger {
            display: flex;
            align-items: center;
            gap: 10px;
            user-select: none;
        }
        .dropdown-content {
            display: none;
            position: absolute;
            top: 70px;
            right: 0;
            background-color: white;
            min-width: 160px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.2);
            border-radius: 0 0 5px 5px;
            z-index: 1000;
        }
        .show { display: block; }

        /* Recipe Detail Specifics */
        .detail-img {
            width: 100%;
            height: 400px;
            object-fit: cover;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .meta { color: #666; font-size: 0.9em; margin-bottom: 20px; border-bottom: 1px solid #eee; padding-bottom: 15px; }
        .action-bar { margin-top: 20px; display: flex; gap: 10px; }
        
        .category-tag {
            color: #ff7e54;
            font-weight: bold;
        }
    </style>
</head>
<body>

    <nav>
        <a href="home.php" class="nav-brand">Thyme to Share</a>
        
        <?php if(isset($_SESSION['user_id'])): ?>
        <div class="user-menu" onclick="toggleDropdown()">
            <div class="user-trigger">
                <span><?php echo htmlspecialchars($_SESSION['username']); ?></span>
                <img src="<?php echo $avatar; ?>" class="user-avatar-small">
                </div>
            <div id="myDropdown" class="dropdown-content">
                <a href="profile.php">My Profile</a>
                <a href="add-updaterecipe.php">Add Recipe</a>
                <a href="myrecipes.php">My Recipes</a>
                <a href="favorites.php">My Favorites</a>
                <a href="logout.php" style="color:red;">Signout</a>
            </div>
        </div>
        <?php else: ?>
            <a href="login.php" style="color:white; text-decoration:none; font-weight:bold;">Login</a>
        <?php endif; ?>
    </nav>

    <main>
        <div class="card" style="max-width: 800px; margin: 0 auto;">
            
            <a href="home.php" style="text-decoration:none; color:#555; display:inline-block; margin-bottom:15px;">← Back to Home</a>

            <?php $img = !empty($recipe['featured_image']) ? $recipe['featured_image'] : 'https://via.placeholder.com/800x400'; ?>
            <img src="<?php echo $img; ?>" alt="Recipe Image" class="detail-img">

            <h1><?php echo htmlspecialchars($recipe['title']); ?></h1>
            <div class="meta">
                By <strong><?php echo htmlspecialchars($recipe['username']); ?></strong> 
                | Posted on <?php echo date("F j, Y", strtotime($recipe['date_posted'])); ?>
                <br>
                Category: <span class="category-tag"><?php echo htmlspecialchars($recipe['category']); ?></span>
                | Prep: <?php echo $recipe['prep_time']; ?>m | Cook: <?php echo $recipe['cooking_time']; ?>m | Servings: <?php echo $recipe['servings']; ?>
            </div>

            <div class="action-bar">
                <a href="toggle_favorite.php?id=<?php echo $recipe['recipe_id']; ?>" class="btn" style="background-color: #e91e63;">
                    <?php echo $is_favorited ? "♥ Remove Favorite" : "♡ Add to Favorites"; ?>
                </a>

                <?php if (isset($_SESSION['user_id']) && $_SESSION['user_id'] == $recipe['user_id']): ?>
                    <a href="add-updaterecipe.php?id=<?php echo $recipe['recipe_id']; ?>" class="btn" style="background-color: #2196F3;">Edit</a>
                    <a href="delete_recipe.php?id=<?php echo $recipe['recipe_id']; ?>" class="btn" style="background-color: #f44336;" onclick="return confirm('Delete this recipe?');">Delete</a>
                <?php endif; ?>
            </div>

            <hr style="margin: 20px 0; border: 0; border-top: 1px solid #eee;">

            <p><em><?php echo htmlspecialchars($recipe['excerpt']); ?></em></p>

            <h3>About</h3>
            <p><?php echo nl2br(htmlspecialchars($recipe['about'])); ?></p>
            
            <h3>Ingredients</h3>
            <p><?php echo nl2br(htmlspecialchars($recipe['ingredients'])); ?></p>
            
            <h3>Instructions</h3>
            <p><?php echo nl2br(htmlspecialchars($recipe['instructions'])); ?></p>

        </div>
    </main>

    <footer><p>&copy; 2026 Thyme to Share</p></footer>
    <script src="main.js"></script>
    <script>
        function toggleDropdown() {
            document.getElementById("myDropdown").classList.toggle("show");
        }
        window.onclick = function(event) {
            if (!event.target.matches('.user-menu') && !event.target.closest('.user-menu')) {
                var dropdowns = document.getElementsByClassName("dropdown-content");
                for (var i = 0; i < dropdowns.length; i++) {
                    var openDropdown = dropdowns[i];
                    if (openDropdown.classList.contains('show')) {
                        openDropdown.classList.remove('show');
                    }
                }
            }
        }
    </script>
</body>
</html>