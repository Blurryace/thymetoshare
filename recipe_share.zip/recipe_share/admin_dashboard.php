<?php
session_start();
require 'tts_config.php';

// SECURITY CHECK: Kick out non-admins
if (!isset($_SESSION['user_id']) || !isset($_SESSION['is_staff']) || $_SESSION['is_staff'] != 1) {
    header("Location: home.php");
    exit();
}

// Stats for the Dashboard
$user_count = $conn->query("SELECT COUNT(*) as count FROM users")->fetch_assoc()['count'];
$recipe_count = $conn->query("SELECT COUNT(*) as count FROM recipes")->fetch_assoc()['count'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard | Thyme to Share</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .admin-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-top: 20px; }
        .stat-card { background: white; padding: 20px; border-radius: 10px; text-align: center; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        .stat-number { font-size: 2.5rem; font-weight: bold; color: #ff7e54; margin: 10px 0; }
        .admin-nav-btn { display: block; background: #333; color: white; padding: 15px; margin-top: 10px; text-decoration: none; border-radius: 5px; text-align: center; font-weight: bold; }
        .admin-nav-btn:hover { background: #555; }
    </style>
</head>
<body>
    <nav>
        <a href="#" class="nav-brand">Thyme to Share (Admin Mode)</a>
        <div>
            <a href="logout.php" style="color:white; text-decoration:none;">Logout</a>
        </div>
    </nav>

    <main>
        <h1>Admin Dashboard</h1>
        <p>Welcome back, <?php echo htmlspecialchars($_SESSION['username']); ?>.</p>

        <div class="admin-grid">
            <div class="stat-card">
                <h3>Total Users</h3>
                <div class="stat-number"><?php echo $user_count; ?></div>
            </div>
            <div class="stat-card">
                <h3>Total Recipes</h3>
                <div class="stat-number"><?php echo $recipe_count; ?></div>
            </div>
        </div>

        <div class="admin-grid">
            <a href="admin_users.php" class="admin-nav-btn">Manage Users</a>
            <a href="admin_recipes.php" class="admin-nav-btn">Manage Recipes</a>
        </div>
    </main>
</body>
</html>