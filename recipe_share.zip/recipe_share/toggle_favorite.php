<?php
session_start();
require 'tts_config.php';

if (!isset($_SESSION['user_id']) || !isset($_GET['id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$recipe_id = $_GET['id'];

// Check if already favorited
$check = $conn->prepare("SELECT * FROM favorites WHERE user_id = ? AND recipe_id = ?");
$check->bind_param("ii", $user_id, $recipe_id);
$check->execute();
$result = $check->get_result();

if ($result->num_rows > 0) {
    // Already favorite? Remove it.
    $stmt = $conn->prepare("DELETE FROM favorites WHERE user_id = ? AND recipe_id = ?");
} else {
    // Not favorite? Add it.
    $stmt = $conn->prepare("INSERT INTO favorites (user_id, recipe_id) VALUES (?, ?)");
}

$stmt->bind_param("ii", $user_id, $recipe_id);
$stmt->execute();

// Go back to the recipe page
header("Location: recipedetail.php?id=" . $recipe_id);
exit();
?>